using System.Drawing.Drawing2D;

namespace Figuras2D
{
    public partial class Form1 : Form
    {

        Graphics? g;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void picPlano_Paint(object sender, PaintEventArgs e)
        {
            //Obtiene el grafico del picture box para graficar
            g = e.Graphics;
            //Dibuja el eje cartesiano 2D
            DibujaEje(g);
            //Creamos una pluma virtual de 1px
            Pen pen = new(Color.Blue, 1);

            //Deshabilita el resize en el formulario
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            //Crea un objeto rectangulo
            Rectangle rec = new(100, 100, 50, 50);
            //Dibuja el rectangulo en el plano
            g.DrawRectangle(pen, rec);
            g.FillRectangle(new SolidBrush(Color.Blue), rec);

            //Crea un objeto triangulo
            Point[] triangulo = [new(200, 150), new(250, 150), new(225, 100)];
            //Dibuja el triangulo en el plano
            g.DrawPolygon(pen, triangulo);
            g.FillPolygon(new LinearGradientBrush(new Point(350, 150), new Point(350, 210), Color.Blue, Color.Red), triangulo);

            //Crea un objeto circulo
            Rectangle circulo = new(550, 150, 50, 50);
            //Dibuja el circulo en el plano
            g.DrawEllipse(pen, circulo);
            g.FillEllipse(new HatchBrush(HatchStyle.Sphere, Color.Red), circulo);


            //Crea un objeto elipse
            Rectangle elipse = new(150, 250, 80, 50);
            //Dibuja la elipse el plano
            g.DrawEllipse(pen, elipse);
            g.FillEllipse(new SolidBrush(Color.Purple), elipse);

            //Crea un objeto poligono
            Point[] poligono = [new(350, 300), new(380, 300), new(390, 275), new(365, 250), new(340, 275)];
            //Dibuja el pentagono en el plano
            g.DrawPolygon(pen, poligono);
            g.FillPolygon(new SolidBrush(Color.Gold), poligono);

            //Crea un objeto rectangulo
            Rectangle rectangulo = new(525, 250, 100, 50);
            //Dibuja el rectangulo en el plano
            g.DrawRectangle(pen, rectangulo);
            g.FillRectangle(new LinearGradientBrush(new Point(525, 100), new Point(525, 50), Color.Coral, Color.AntiqueWhite), rectangulo);

            //Crea un objeto triangulo
            Point[] triangulo1 = [new(150, 400), new(250, 400), new(150, 350)];
            //Dibuja el triangulo en el clima
            g.DrawPolygon(pen, triangulo1);
            g.FillPolygon(new LinearGradientBrush (new Point(350, 150), new Point(350, 215), Color.SkyBlue, Color.Silver), triangulo1);
        }

        private void DibujaEje(Graphics g)
        {
            //Creamos una pluma virtual de 1px
            Pen pen = new(Color.LightGray, 1);
            //Dibuja el eje X
            g.DrawLine(pen, 0, picPlano.Height / 2, picPlano.Width, picPlano.Height / 2);
            //Dibuja el eje Y
            g.DrawLine(pen, picPlano.Width / 2, 0, picPlano.Width / 2, picPlano.Height);
        }
    }
}