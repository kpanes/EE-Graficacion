using System.Diagnostics.Eventing.Reader;
using System.Drawing.Drawing2D;

namespace Escala2D
{
    public partial class Form1 : Form
    {

        Graphics? g;
        int ex = 0; //valor de escala en x
        int ey = 0; //valor de escala en y
        int emin = 0; //tama�o maximo de escala
        int emax = 200; //tama�o minimo de escala
        int tipo = 1; //Tipo e figura: 1 cuadrado, 2 circulo

        public Form1()
        {
            InitializeComponent();
            //Deshabilita el resize en el formulario
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void picPlano_Paint(object sender, PaintEventArgs e)
        {
            //Obtiene el grafico del picture box para graficar
            g = e.Graphics;
            //Dibuja el eje cartesiano 2D
            DibujaEje(g);
            //Creamos una pluma virtual de 1px
            Pen pen = new(Color.Blue, 1);

            if (tipo == 1)
            {
                //Crea un objeto rectangulo en la posicion
                Rectangle rec = new(50, 50, 50 + ex, 50 + ey);
                //Dibuja el rectangulo en el plano
                g.FillRectangle(Brushes.Blue, rec);

                using (Font fuente = new Font("Consolas", 8))
                {
                    g.DrawString($"Ancho:{50 + ex}, Alto:{50 + ey}, Tipo: Cuadrado", fuente, Brushes.Black, new Point(10, picPlano.Height - 20));
                }
            }
            else
            {

                //Crea un objeto circulo
                Rectangle circulo = new(50, 50, 50 + ex, 50 + ey);
                //Dibuja el circulo en el plano
                g.FillEllipse(Brushes.Coral, circulo);

                using (Font fuente = new Font("Consolas", 8))
                {
                    g.DrawString($"Ancho:{50 + ex}, Alto:{50 + ey}, Tipo: Circulo", fuente, Brushes.Black, new Point(10, picPlano.Height -20));
                }
            }
        }

        private void DibujaEje(Graphics g)
        {
            //Creamos una pluma virtual de 1px
            Pen pen = new(Color.LightGray, 1);
            //Dibuja el eje X
            g.DrawLine(pen, 0, picPlano.Height / 2, picPlano.Width, picPlano.Height / 2);
            //Dibuja el eje Y
            g.DrawLine(pen, picPlano.Width / 2, 0, picPlano.Width / 2, picPlano.Height);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //Revisamos que tecla presiono el usuario
            switch(e.KeyCode)
            {
                case Keys.Up:
                    // Incremento
                    if (ex < emax)
                    {
                        ex++;
                        ey++;
                    }
                    //Vuelve a dibujar el PictureBox
                    picPlano.Refresh();
                    break;
                case Keys.Down:
                    //Decremento
                    if (ex > emin)
                    {
                        ex--;
                        ey--;
                    }
                    //Vuelve a dibujar el PictureBox
                    picPlano.Refresh();
                    break;
                case Keys.F:
                    //Cambia de figura
                    if (tipo == 1)
                        tipo = 2;  //Circulo
                    else
                        tipo = 1;  //Cuadrado
                    //Vuelve a dibujar el PictureBox
                    picPlano.Refresh();
                    break;

            }
        }
    }
}