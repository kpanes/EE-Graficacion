namespace LineasRectas
{
    public partial class Form1 : Form
    {

        Graphics? g;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void picPlano_Paint(object sender, PaintEventArgs e)
        {
            //Obtiene el grafico del picture box para graficar
            g = e.Graphics;
            //Creamos una pluma virtual de 1px
            Pen pen = new(Color.Blue, 1);

            //Crea el punto inicial de la linea
            Point point1 = new(50, 50);
            //Crea el punto final de la linea
            Point point2 = new(200, 50);

            //Dibuja una linea recta
            g.DrawLine(pen, point1, point2);

            //Obtiene el grafico del picture box para graficar
            g = e.Graphics;
            //Dibuja el eje cartesiano 2D
            DibujaEje(g);
        }

        private void DibujaEje(Graphics g)
        {
            //Creamos una pluma virtual de 1px
            Pen pen = new(Color.LightGray, 1);
            //Dibuja el eje X
            g.DrawLine(pen, 0, picPlano.Height / 2, picPlano.Width, picPlano.Height / 2);
            //Dibuja el eje Y
            g.DrawLine(pen, picPlano.Width / 2, 0, picPlano.Width / 2, picPlano.Height);
        }
    }
}